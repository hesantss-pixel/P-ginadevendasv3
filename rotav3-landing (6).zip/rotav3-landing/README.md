# rotav3 Systems — Landing page

Landing page comercial com dez blocos: cabeçalho, apresentação, desafios/benefícios, mapa operacional, personalização, funcionamento, recursos, demonstração, FAQ e rodapé. Não publicada; sem domínio ou integrações comerciais.

## Instalar e executar

Requisitos: Node.js 22.12+ e npm, ou Bun 1.3+.

```sh
npm install
npm run dev
```

Abra o endereço indicado no terminal. Com Bun: `bun install` e `bun run dev`.

## Build e testes

```sh
npm run build
npm test
```

O projeto preserva a estrutura React 19 + TypeScript + Vite + TanStack Start do ambiente original, com Tailwind CSS v4. Não usa Next.js nem React Router. O plugin existente configura o build para Cloudflare; a publicação futura depende da plataforma escolhida e não foi executada nesta etapa. `npm run preview` permite inspecionar o resultado do build quando suportado pelo destino configurado.

## Organização

- `src/routes/index.tsx`: página e metadados.
- `src/routes/__root.tsx`: documento HTML e configuração compartilhada.
- `src/sections/LandingPage.tsx`: composição da página.
- `src/components/Brand.tsx`: logo original.
- `src/components/Dashboard.tsx`: interface reutilizável, filtros e paradas.
- `src/components/RouteMap.tsx`: mapa Leaflet carregado somente no navegador.
- `src/components/DemoDialog.tsx`: prévia interativa e formulário demonstrativo.
- `src/data/demo.ts`: dados, rotas, navegação e FAQ.
- `src/styles.css`: cores OKLCH, fontes, espaçamento, bordas e adaptação móvel.
- `src/test/`: testes de filtros e navegação.
- `src/assets/`: logo e fotografia ilustrativa.
- `public/favicon.png`: ícone extraído da marca original.

## Logo original

O único anexo recebido foi uma captura da página, não um arquivo independente de logo. A marca exibida foi recortada diretamente dessa captura, sem redesenho, e tem resolução limitada. No ZIP, substitua `src/assets/rotav3-logo.png` por uma exportação original com fundo transparente para melhorar a nitidez. Mantenha esse nome; o componente já a utiliza. Na versão do editor, a logo é referenciada pelo arquivo `rotav3-logo.png.asset.json`.

O ZIP inclui a logo como imagem local, sem depender do serviço de arquivos do editor. A fotografia do caminhão é ilustrativa, gerada para esta página; não representa um cliente ou uma operação real.

## Demonstração e limites

Todos os pontos, endereços, empresas de exemplo, linhas e status são demonstrativos. As linhas ilustram percursos; não são calculadas por um serviço de roteirização. Não há rastreamento real ou otimização de rotas nesta landing. Os filtros alternam coletas e entregas; marcadores abrem informações; o mapa permite zoom e movimentação. O formulário valida no navegador, mas não envia, recebe ou armazena contatos. Não há banco de dados, pagamentos, e-mail, analytics ou integrações comerciais.

O mapa usa tiles públicos OpenStreetMap e requer internet. Preserve a atribuição e consulte https://operations.osmfoundation.org/policies/tiles/ antes de uso comercial com tráfego significativo; escolha um provedor apropriado quando necessário. Fontes são locais. Sem JavaScript, a página comercial continua visível e o mapa mostra o estado de carregamento.

Contatos institucionais, privacidade, termos e depoimentos não foram inventados: os espaços correspondentes indicam preparação. Antes de publicar, fornecer textos legais, contato real e configurar o envio seguro do formulário.

## Verificações executadas

- Quatro testes Vitest aprovados: rota principal e três filtros.
- Verificação automática do ambiente: build OK.
- Chromium: filtros, pop-up, FAQ, formulário demonstrativo, prévia interativa e menu móvel.
- Visualização a 1280 px e 390 px: nenhuma rolagem horizontal móvel detectada; nenhum erro JavaScript observado.

## Documentação e licenças

- React: https://react.dev/ — MIT.
- Vite: https://vite.dev/guide/ — MIT.
- TypeScript: https://www.typescriptlang.org/docs/ — Apache-2.0.
- Tailwind: https://tailwindcss.com/docs — MIT.
- Lucide: https://lucide.dev/guide/packages/lucide-react — ISC.
- Leaflet: https://leafletjs.com/ — BSD-2-Clause.
- React Leaflet: https://react-leaflet.js.org/ — Hippocratic-2.1; revisar suas condições para o uso pretendido.
- Motion: https://motion.dev/docs/react — consultada; não instalada, pois CSS discreto é suficiente para esta versão.

React Leaflet 5 requer React 19 e Leaflet 1.9; as versões são compatíveis. Não foram usados templates de terceiros. A referência e a marca fornecidas pertencem a seus respectivos titulares.
