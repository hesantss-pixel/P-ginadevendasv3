<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the TanStack Start React/TypeScript/Vite bootstrap; the landing is a single scrolling index route because its navigation explicitly targets page sections.
- Isolate Leaflet in the lazy RouteMap module behind ClientOnly so SSR never evaluates DOM-dependent imports.
- Keep demonstration stops and route paths in a browser-safe data module, shared by all dashboard instances, to preserve consistent filtering.
- Define visual tokens and section styles centrally in src/styles.css; use Button variants for interactive controls to preserve the reference identity.
