import { describe, expect, it } from 'vitest';
import { filterStops } from '../data/demo';
describe('Filtros demonstrativos', () => {
 it('Coletas exibe somente os três pontos de coleta', () => { const rows=filterStops('Coletas'); expect(rows.map(r=>r.id)).toEqual([1,3,5]); expect(rows.every(r=>r.kind==='Coleta')).toBe(true); });
 it('Entregas exibe somente os três pontos de entrega', () => { expect(filterStops('Entregas').map(r=>r.id)).toEqual([2,4,6]); });
 it('Todas inclui as seis paradas demonstrativas', () => { expect(filterStops('Todas').map(r=>r.id)).toEqual([1,2,3,4,5,6]); });
});
