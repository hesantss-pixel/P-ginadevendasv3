import { createFileRoute } from "@tanstack/react-router";
import { LandingPage } from '@/sections/LandingPage';

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: 'rotav3 Systems — Suas rotas organizadas' },
    { name: 'description', content: 'Organize rotas, coletas e entregas em um só lugar. Conheça o sistema logístico adaptado à sua empresa.' },
    { property: 'og:title', content: 'rotav3 Systems — Suas rotas organizadas' },
    { property: 'og:description', content: 'Planejamento de rotas, visualização no mapa e personalização para a realidade da sua operação.' },
    { property: 'og:type', content: 'website' },
    { name: 'twitter:card', content: 'summary_large_image' },
  ] }),
  component: LandingPage,
});
