export type StopFilter = 'Todas' | 'Coletas' | 'Entregas';
export type DemoStop = { id: number; kind: 'Coleta' | 'Entrega'; name: string; address: string; position: [number, number]; route: 'green' | 'blue' | 'gold' };
export const stops: DemoStop[] = [
  { id: 1, kind: 'Coleta', name: 'Depósito Central', address: 'Rua da Consolação, 720', position: [-23.548, -46.655], route: 'blue' },
  { id: 2, kind: 'Entrega', name: 'Unidade Paulista', address: 'Av. Paulista, 900', position: [-23.563, -46.651], route: 'blue' },
  { id: 3, kind: 'Coleta', name: 'Centro de Distribuição', address: 'Rua Augusta, 1800', position: [-23.558, -46.665], route: 'green' },
  { id: 4, kind: 'Entrega', name: 'Unidade Pinheiros', address: 'Rua dos Pinheiros, 420', position: [-23.566, -46.68], route: 'green' },
  { id: 5, kind: 'Coleta', name: 'Ponto Vila Mariana', address: 'Rua Vergueiro, 2000', position: [-23.577, -46.639], route: 'gold' },
  { id: 6, kind: 'Entrega', name: 'Unidade Paraíso', address: 'Rua Afonso de Freitas, 180', position: [-23.573, -46.646], route: 'gold' },
];
export const routePaths: Record<DemoStop['route'], [number, number][]> = {
  blue: [[-23.548,-46.655],[-23.547,-46.65],[-23.553,-46.647],[-23.557,-46.651],[-23.563,-46.651]],
  green: [[-23.558,-46.665],[-23.55,-46.67],[-23.554,-46.676],[-23.561,-46.677],[-23.566,-46.68]],
  gold: [[-23.577,-46.639],[-23.581,-46.647],[-23.581,-46.657],[-23.576,-46.659],[-23.573,-46.646]],
};
export function filterStops(filter: StopFilter) { return stops.filter(s => filter === 'Todas' || s.kind === (filter === 'Coletas' ? 'Coleta' : 'Entrega')); }
export const navigation = [ ['O Sistema','sistema'], ['Diferenciais','diferenciais'], ['Personalização','personalizacao'], ['Como Funciona','como-funciona'], ['Perguntas Frequentes','faq'] ];
export const faqs = [
  ['Como funciona a roteirização automática?', 'O sistema organiza os pontos de coleta e entrega para apoiar o planejamento das rotas. Os processos e critérios da sua operação são definidos na configuração da solução.'],
  ['O sistema pode ser adaptado à minha empresa?', 'Sim. A identidade visual, os campos e os processos podem ser configurados de acordo com as necessidades apresentadas pela sua empresa.'],
  ['Como aparecem as coletas e entregas no mapa?', 'Os pontos são identificados por marcadores, com informações sobre cada parada. Nesta página, todos os endereços e rotas são exemplos demonstrativos.'],
  ['Quanto custa desenvolver ou personalizar o sistema?', 'O escopo é definido após conhecer sua operação. Solicite uma demonstração para conversar sobre suas necessidades e a personalização desejada.'],
];