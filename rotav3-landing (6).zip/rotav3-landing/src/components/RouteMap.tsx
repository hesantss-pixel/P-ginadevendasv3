import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';
import L from 'leaflet';
import { filterStops, routePaths, type StopFilter } from '@/data/demo';
export default function RouteMap({ filter, selected }: { filter: StopFilter; selected?: number | undefined }) {
  const visible = filterStops(filter);
  return <MapContainer center={[-23.565, -46.657]} zoom={13} scrollWheelZoom={false} className="route-map" attributionControl={true}>
    <TileLayer attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>' url="https://tile.openstreetmap.org/{z}/{x}/{y}.png" />
    {Object.entries(routePaths).map(([color, points]) => <Polyline key={color} positions={points} pathOptions={{ className: `route-line route-${color}`, weight: 3 }} />)}
    {visible.map(stop => <Marker key={`${stop.id}-${selected}`} position={stop.position} icon={L.divIcon({ className: 'map-marker-wrapper', html: `<span class="map-pin route-${stop.route} ${selected === stop.id ? 'selected-pin' : ''}">${stop.kind === 'Coleta' ? 'C' : 'E'}</span>`, iconSize: [24,32], iconAnchor: [12,32] })}><Popup><strong>{stop.kind} · {stop.name}</strong><br/>{stop.address}<br/><small>Dados demonstrativos · Pendente</small></Popup></Marker>)}
  </MapContainer>;
}