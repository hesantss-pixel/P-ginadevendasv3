import logo from '@/assets/rotav3-logo.png';
export function Brand() { return <img className="brand" src={logo} width="137" height="35" alt="rotav3 Systems" />; }