import { lazy, Suspense, useState } from 'react';
import { ClientOnly } from '@tanstack/react-router';
import { House, Map, MapPin, Package, Truck, ChartNoAxesCombined, Settings, ChevronDown, CircleUserRound, Bell, LayoutGrid } from 'lucide-react';
import { Brand } from './Brand';
import { Button } from './ui/button';
import { filterStops, type StopFilter } from '@/data/demo';
const RouteMap = lazy(() => import('./RouteMap'));
const sidebarItems = [[House,'Início'],[Map,'Planejamento de Rotas'],[MapPin,'Pontos no Mapa'],[Package,'Coletas e Entregas'],[Truck,'Veículos'],[ChartNoAxesCombined,'Relatórios'],[Settings,'Configurações']] as const;
export function Dashboard({ miniature = false, company, theme = '' }: { miniature?: boolean; company?: string; theme?: string }) {
  const [filter, setFilter] = useState<StopFilter>('Todas');
  const [selected, setSelected] = useState<number>();
  return <div className={`dashboard ${miniature ? 'dashboard-mini' : ''} ${theme}`}>
    <aside className="dashboard-sidebar"><Brand/>{sidebarItems.map(([Icon,label], i) => <div key={label} className={`sidebar-row ${i === 1 ? 'sidebar-active' : ''}`}><Icon size={11}/><span>{label}</span></div>)}</aside>
    <div className="dashboard-main"><div className="dashboard-topbar"><LayoutGrid size={12}/><select aria-label="Período demonstrativo" defaultValue="Hoje"><option>Hoje</option><option>Esta semana</option></select><span className="demo-label">Demonstração</span><Bell size={11}/><CircleUserRound size={17}/><span>{company || 'Minha Empresa'}</span><ChevronDown size={11}/></div>
      <div className="dashboard-workspace"><div className="map-area"><ClientOnly fallback={<div className="map-loading">Carregando mapa…</div>}><Suspense fallback={<div className="map-loading">Carregando mapa…</div>}><RouteMap filter={filter} selected={selected}/></Suspense></ClientOnly><div className="map-caption">Rotas ilustrativas · São Paulo</div></div>
      <aside className="stops-panel"><h3>Sequência de Paradas <span>ⓘ</span></h3><div className="map-filters">{(['Todas','Coletas','Entregas'] as const).map(f => <Button key={f} variant="dashboard" aria-pressed={filter === f} onClick={() => setFilter(f)}>{f}</Button>)}</div><div className="stop-list">{filterStops(filter).map(s => <Button variant="dashboard" className={`stop-row route-${s.route}`} key={s.id} onClick={() => setSelected(s.id)} aria-label={`Selecionar ${s.kind} ${s.name}`}><span className="stop-number">{s.id}</span><span className="stop-detail"><strong>{s.kind}</strong><small>{s.address}</small><span className="stop-place">{s.name}</span></span><span className="stop-status">Pendente</span></Button>)}</div></aside></div>
    </div>
  </div>;
}